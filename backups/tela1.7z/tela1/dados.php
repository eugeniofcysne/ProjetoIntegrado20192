<?php
session_start();
$paraofuscar = $_POST["ofusca"];
$paradesofuscar = $_POST["desofusca"];
function ofuscar ($paraofuscar) {
    return 0;
}
function desofuscar ($paradesofuscar) {
    return 0;
}